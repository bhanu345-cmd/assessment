import React from 'react';
const Home=()=>{
    return <h1 style={{textAlign:'center'}}> Please use /dashboard or /form to navigate.</h1>
}
export default Home;